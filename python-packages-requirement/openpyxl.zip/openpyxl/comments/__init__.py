# Copyright (c) 2010-2020 openpyxl


from .comments import Comment
